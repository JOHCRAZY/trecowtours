<?php

namespace common\models;

use \common\models\base\Bookings as BaseBookings;

/**
 * This is the model class for table "bookings".
 */
class Bookings extends BaseBookings
{

}
