<?php

namespace common\models;

use \common\models\base\ServiceHighlights as BaseServiceHighlights;

/**
 * This is the model class for table "service_highlights".
 */
class ServiceHighlights extends BaseServiceHighlights
{

}
