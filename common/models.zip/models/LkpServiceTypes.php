<?php

namespace common\models;

use \common\models\base\LkpServiceTypes as BaseLkpServiceTypes;

/**
 * This is the model class for table "lkp_service_types".
 */
class LkpServiceTypes extends BaseLkpServiceTypes
{

}
