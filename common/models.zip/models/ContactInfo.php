<?php

namespace common\models;

use \common\models\base\ContactInfo as BaseContactInfo;

/**
 * This is the model class for table "contact_info".
 */
class ContactInfo extends BaseContactInfo
{

}
