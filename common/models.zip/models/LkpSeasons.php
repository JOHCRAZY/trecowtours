<?php

namespace common\models;

use \common\models\base\LkpSeasons as BaseLkpSeasons;

/**
 * This is the model class for table "lkp_seasons".
 */
class LkpSeasons extends BaseLkpSeasons
{

}
