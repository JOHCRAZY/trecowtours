<?php

namespace common\models;

use \common\models\base\Events as BaseEvents;

/**
 * This is the model class for table "events".
 */
class Events extends BaseEvents
{

}
