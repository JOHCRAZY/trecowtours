<?php

namespace common\models;

use \common\models\base\Locations as BaseLocations;

/**
 * This is the model class for table "locations".
 */
class Locations extends BaseLocations
{

}
