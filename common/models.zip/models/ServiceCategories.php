<?php

namespace common\models;

use \common\models\base\ServiceCategories as BaseServiceCategories;

/**
 * This is the model class for table "service_categories".
 */
class ServiceCategories extends BaseServiceCategories
{

}
