<?php

namespace common\models;

use \common\models\base\ServiceImages as BaseServiceImages;

/**
 * This is the model class for table "service_images".
 */
class ServiceImages extends BaseServiceImages
{

}
