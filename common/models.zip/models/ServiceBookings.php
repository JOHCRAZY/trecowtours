<?php

namespace common\models;

use \common\models\base\ServiceBookings as BaseServiceBookings;

/**
 * This is the model class for table "service_bookings".
 */
class ServiceBookings extends BaseServiceBookings
{

}
