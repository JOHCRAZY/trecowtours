<?php

namespace common\models;

use \common\models\base\ServicePricing as BaseServicePricing;

/**
 * This is the model class for table "service_pricing".
 */
class ServicePricing extends BaseServicePricing
{

}
