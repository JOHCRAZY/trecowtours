<?php

namespace common\models;

use \common\models\base\Customers as BaseCustomers;

/**
 * This is the model class for table "customers".
 */
class Customers extends BaseCustomers
{

}
