<?php

namespace common\models;

use \common\models\base\Activities as BaseActivities;

/**
 * This is the model class for table "activities".
 */
class Activities extends BaseActivities
{

}
