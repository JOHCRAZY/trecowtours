<?php

namespace common\models;

use \common\models\base\lookupServiceTypes as BaselookupServiceTypes;

/**
 * This is the model class for table "lkp_service_types".
 */
class lookupServiceTypes extends BaselookupServiceTypes
{

}
