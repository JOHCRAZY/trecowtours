<?php

namespace common\models;

use \common\models\base\TourActivities as BaseTourActivities;

/**
 * This is the model class for table "tour_activities".
 */
class TourActivities extends BaseTourActivities
{

}
