<?php

namespace common\models;

use \common\models\base\TourImages as BaseTourImages;

/**
 * This is the model class for table "tour_images".
 */
class TourImages extends BaseTourImages
{

}
