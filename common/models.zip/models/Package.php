<?php

namespace common\models;

use \common\models\base\Package as BasePackage;

/**
 * This is the model class for table "package_inclusions".
 */
class Package extends BasePackage
{

}
