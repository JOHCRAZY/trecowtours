<?php

namespace common\models;

use \common\models\base\ServiceLocations as BaseServiceLocations;

/**
 * This is the model class for table "service_locations".
 */
class ServiceLocations extends BaseServiceLocations
{

}
