<?php

namespace common\models;

use \common\models\base\Customer as BaseCustomer;

/**
 * This is the model class for table "customers".
 */
class Customer extends BaseCustomer
{

}
