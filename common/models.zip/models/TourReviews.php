<?php

namespace common\models;

use \common\models\base\TourReviews as BaseTourReviews;

/**
 * This is the model class for table "tour_reviews".
 */
class TourReviews extends BaseTourReviews
{

}
