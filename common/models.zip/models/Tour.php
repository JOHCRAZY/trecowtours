<?php

namespace common\models;

use \common\models\base\Tour as BaseTour;

/**
 * This is the model class for table "tours".
 */
class Tour extends BaseTour
{

}
