<?php

namespace common\models;

use \common\models\base\Contact as BaseContact;

/**
 * This is the model class for table "contact_info".
 */
class Contact extends BaseContact
{

}
