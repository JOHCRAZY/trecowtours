<?php

namespace common\models;

use \common\models\base\ServiceInclusions as BaseServiceInclusions;

/**
 * This is the model class for table "service_inclusions".
 */
class ServiceInclusions extends BaseServiceInclusions
{

}
