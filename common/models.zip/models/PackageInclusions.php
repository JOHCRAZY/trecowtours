<?php

namespace common\models;

use \common\models\base\PackageInclusions as BasePackageInclusions;

/**
 * This is the model class for table "package_inclusions".
 */
class PackageInclusions extends BasePackageInclusions
{

}
