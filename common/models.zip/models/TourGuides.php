<?php

namespace common\models;

use \common\models\base\TourGuides as BaseTourGuides;

/**
 * This is the model class for table "tour_guides".
 */
class TourGuides extends BaseTourGuides
{

}
