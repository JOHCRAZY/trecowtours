<?php

namespace common\models;

use \common\models\base\Tours as BaseTours;

/**
 * This is the model class for table "tours".
 */
class Tours extends BaseTours
{

}
