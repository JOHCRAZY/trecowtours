<?php

namespace common\models;

use \common\models\base\ServiceToCategory as BaseServiceToCategory;

/**
 * This is the model class for table "service_to_category".
 */
class ServiceToCategory extends BaseServiceToCategory
{

}
