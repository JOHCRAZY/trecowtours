<?php

namespace common\models;

use \common\models\base\Reviews as BaseReviews;

/**
 * This is the model class for table "tour_reviews".
 */
class Reviews extends BaseReviews
{

}
