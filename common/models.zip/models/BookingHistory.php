<?php

namespace common\models;

use \common\models\base\BookingHistory as BaseBookingHistory;

/**
 * This is the model class for table "booking_history".
 */
class BookingHistory extends BaseBookingHistory
{

}
