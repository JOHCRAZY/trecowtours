<?php

namespace common\models;

use \common\models\base\BookingPayments as BaseBookingPayments;

/**
 * This is the model class for table "booking_payments".
 */
class BookingPayments extends BaseBookingPayments
{

}
