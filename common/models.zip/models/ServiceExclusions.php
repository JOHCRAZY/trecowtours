<?php

namespace common\models;

use \common\models\base\ServiceExclusions as BaseServiceExclusions;

/**
 * This is the model class for table "service_exclusions".
 */
class ServiceExclusions extends BaseServiceExclusions
{

}
