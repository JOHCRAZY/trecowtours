<?php

namespace common\models;

use \common\models\base\TourGuidesAssignments as BaseTourGuidesAssignments;

/**
 * This is the model class for table "tour_guides_assignments".
 */
class TourGuidesAssignments extends BaseTourGuidesAssignments
{

}
