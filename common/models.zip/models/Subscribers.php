<?php

namespace common\models;

use Yii;
use yii\db\ActiveRecord;
use yii\behaviors\TimestampBehavior;
use yii\db\Expression;

/**
 * This is the model class for table "subscribers".
 *
 * @property int $subscriber_id
 * @property int $email
 * @property string $created_at
 */
class Subscribers extends ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'subscribers';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['email'], 'required'],
            [['email'], 'email'],
            [['email'], 'string', 'max' => 255],
            [['created_at'], 'default', 'value' => new Expression('NOW()')],
            [['created_at'], 'safe'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'subscriber_id' => 'Subscriber ID',
            'email' => 'Email',
            'created_at' => 'Created At',
        ];
    }
    
  
}