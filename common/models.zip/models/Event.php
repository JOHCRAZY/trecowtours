<?php

namespace common\models;

use \common\models\base\Event as BaseEvent;

/**
 * This is the model class for table "events".
 */
class Event extends BaseEvent
{

}
