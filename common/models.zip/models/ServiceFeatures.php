<?php

namespace common\models;

use \common\models\base\ServiceFeatures as BaseServiceFeatures;

/**
 * This is the model class for table "service_features".
 */
class ServiceFeatures extends BaseServiceFeatures
{

}
