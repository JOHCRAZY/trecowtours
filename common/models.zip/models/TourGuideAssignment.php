<?php

namespace common\models;

use \common\models\base\TourGuideAssignment as BaseTourGuideAssignment;

/**
 * This is the model class for table "tour_guides_assignments".
 */
class TourGuideAssignment extends BaseTourGuideAssignment
{

}
